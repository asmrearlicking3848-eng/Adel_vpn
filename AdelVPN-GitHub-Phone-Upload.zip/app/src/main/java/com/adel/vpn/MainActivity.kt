package com.adel.vpn

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.URL
import java.util.Base64

private data class Relay(val country: String, val ip: String, val ping: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AdelScreen() }
    }
}

@Composable
private fun AdelScreen() {
    val scope = rememberCoroutineScope()
    var relays by remember { mutableStateOf<List<Relay>>(emptyList()) }
    var status by remember { mutableStateOf("برای دریافت فهرست سرورها، دکمه زیر را بزنید") }
    var loading by remember { mutableStateOf(false) }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Color(0xFF35D0A0),
        background = Color(0xFF0B1220),
        surface = Color(0xFF151F30)
    )) {
        Column(
            Modifier.fillMaxSize().background(Color(0xFF0B1220)).padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(24.dp))
            Text("ADEL VPN", color = Color(0xFF35D0A0), fontSize = 29.sp, fontWeight = FontWeight.Black)
            Text("اتصال آزاد • انتخاب سرور", color = Color.LightGray, fontSize = 14.sp)
            Spacer(Modifier.height(28.dp))
            Box(
                Modifier.size(172.dp).background(Color(0xFF15283A), RoundedCornerShape(100.dp)),
                contentAlignment = Alignment.Center
            ) {
                Text("A", color = Color(0xFF35D0A0), fontSize = 76.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(20.dp))
            Text("اتصال VPN هنوز فعال نیست", color = Color.White, fontWeight = FontWeight.Bold)
            Text(status, color = Color.LightGray, fontSize = 12.sp)
            Spacer(Modifier.height(18.dp))
            Button(
                onClick = {
                    scope.launch {
                        loading = true
                        status = "در حال دریافت فهرست سرورها..."
                        try {
                            val result = withContext(Dispatchers.IO) { fetchRelays() }
                            relays = result
                            status = "تعداد سرورهای دریافت‌شده: ${result.size}"
                        } catch (e: Exception) {
                            status = "خطا در دریافت سرورها؛ اینترنت را بررسی کنید"
                        } finally { loading = false }
                    }
                },
                enabled = !loading,
                modifier = Modifier.fillMaxWidth().height(52.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF159B78))
            ) { Text(if (loading) "لطفاً صبر کنید..." else "دریافت سرورهای رایگان") }

            Spacer(Modifier.height(18.dp))
            Text("فهرست سرورها (VPN Gate)", color = Color.White, fontWeight = FontWeight.Bold)
            LazyColumn(Modifier.fillMaxWidth().weight(1f)) {
                items(relays.take(30)) { relay ->
                    Card(
                        Modifier.fillMaxWidth().padding(vertical = 4.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF152235))
                    ) {
                        Row(Modifier.padding(12.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("${relay.country}  •  ${relay.ip}", color = Color.White)
                            Text("${relay.ping} ms", color = Color(0xFF35D0A0))
                        }
                    }
                }
            }
            Text(
                "نسخه آزمایشی: این برنامه هنوز تونل VPN ایجاد نمی‌کند. سرورهای داوطلب ممکن است ثبت اطلاعات داشته باشند.",
                color = Color(0xFFFFC27A), fontSize = 11.sp
            )
        }
    }
}

private fun fetchRelays(): List<Relay> {
    val text = URL("https://www.vpngate.net/api/iphone/").readText()
    return text.lineSequence()
        .filter { it.isNotBlank() && !it.startsWith("*") && !it.startsWith("#") }
        .mapNotNull { line ->
            val p = line.split(",")
            if (p.size < 15) return@mapNotNull null
            try {
                val country = p[5].trim('"')
                val ip = p[1].trim('"')
                val ping = p[ pingIndex(p) ].trim('"')
                if (ip.isBlank() || country.isBlank()) null else Relay(country, ip, ping)
            } catch (_: Exception) { null }
        }
        .take(100)
        .toList()
}

private fun pingIndex(parts: List<String>) = 3
